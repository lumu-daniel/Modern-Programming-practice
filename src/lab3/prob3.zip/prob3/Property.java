package lab3.prob3;

public class Property {
    private Address address;

    public Property(Address address) {
        this.address = address;
    }

    public Address getAddress() {
        return address;
    }

    public double computeRent(){
        return 0.0;
    }
}
